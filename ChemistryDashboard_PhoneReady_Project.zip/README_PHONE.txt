Open this project in AndroidIDE on your phone, then build the APK.

Steps:
1) Install AndroidIDE from its official site, GitHub Releases, GitHub Actions, or F-Droid.
2) Unzip this project on your phone.
3) Open the project folder in AndroidIDE.
4) Build APK.
5) Install the APK.
